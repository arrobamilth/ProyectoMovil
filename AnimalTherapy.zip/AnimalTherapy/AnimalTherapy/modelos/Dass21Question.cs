﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AnimalTherapy.modelos
{
    public class DASS21Question
    {
        public string Text { get; set; }
        public int Answer { get; set; } // 0: No me aplicó en absoluto, 1: Me aplicó en parte, 2: Me aplicó en gran parte, 3: Me aplicó completamente
    }
}
