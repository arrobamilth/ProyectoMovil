﻿using AnimalTherapy.pages;

namespace AnimalTherapy
{
    public partial class MainPage : ContentPage
    {
        int count = 0;

        public MainPage()
        {
            InitializeComponent();
        }

        protected override async void OnAppearing()
        {
            base.OnAppearing();

            // Mostrar la pantalla de bienvenida por 5 segundos
            await Task.Delay(4000);

            var Login = new Login();

            Navigation.InsertPageBefore(Login, this);
            await Navigation.PopAsync();
        }

    }

}
