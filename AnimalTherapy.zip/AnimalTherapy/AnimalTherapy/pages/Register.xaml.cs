using Microsoft.Maui.ApplicationModel.Communication;

namespace AnimalTherapy.pages;

public partial class Register : ContentPage
{
    public Register()
    {
        InitializeComponent();
    }

    private async void OnRegisterButtonClicked(object sender, EventArgs e)
    {
        // Suponiendo que ya has validado los campos de entrada (nombre, tel�fono, email, contrase�a)

        // Mensaje de registro exitoso
        await DisplayAlert("Registro exitoso", "Te has registrado con �xito.", "OK");

        // Redirigir a la p�gina de inicio de sesi�n
        await Navigation.PushAsync(new Login());
    }
}


























