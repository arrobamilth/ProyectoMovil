namespace AnimalTherapy.pages;

public partial class Login : ContentPage
{
	public Login()
	{
		InitializeComponent();
	}


    private async void OnCreateAccountButtonClicked(object sender, EventArgs e)
    {
        // Navegar a la p�gina de registro
        await Navigation.PushAsync(new Register());
    }
}
