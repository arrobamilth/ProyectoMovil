<footer>
    <p>Copyright © 2024 • Chaira Zapa - María Zabaleta.</p>
</footer>
