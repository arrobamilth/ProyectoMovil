<header>
    <div class="header__container">
        <img src="../assets/img/logoth.png" alt="Logo" class="logo">
        <h1 class="header__title">ANIMAL THERAPY</h1>
    </div>
</header>
