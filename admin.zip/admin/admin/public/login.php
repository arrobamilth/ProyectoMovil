<?php
require_once '../includes/db.php';
require_once '../includes/functions.php';

session_start();

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $correo = sanitize_input($_POST['username']);
    $contrasena = sanitize_input($_POST['password']);

    if (validate_email($correo)) {
        $usuario = verify_user($conn, $correo, $contrasena);

        if ($usuario) {
            $_SESSION['usuario_id'] = $usuario['id'];
            redirect('dashboard.php');
        } else {
            $error = "Contraseña incorrecta o usuario no registrado.";
        }
    } else {
        $error = "Correo electrónico inválido.";
    }
    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Animal Therapy</title>
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
    <?php include '../templates/header.php'; ?>
    <main>
        <div class="login-container">
            <h2>Iniciar Sesión</h2>
            <form method="POST" action="">
                <input type="text" name="username" placeholder="Ingrese su E-mail." required>
                <input type="password" name="password" placeholder="Ingrese su contraseña." required>
                <button type="submit">Ingresar</button>
            </form>
            <?php if (!empty($error)): ?>
                <p style="color:red;"><?php echo htmlspecialchars($error); ?></p>
            <?php endif; ?>
        </div>
    </main>
    <?php include '../templates/footer.php'; ?>
</body>
</html>
