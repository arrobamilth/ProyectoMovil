<?php
session_start();

// Verificar si el usuario ha iniciado sesión
if (!isset($_SESSION['usuario_id'])) {
    header("Location: login.php"); // Redirigir al login si no hay sesión
    exit();
}

// Aquí conectamos a la base de datos
require_once '../includes/db.php';

// Consultas para obtener los datos que se mostrarán en los paneles
// Número de usuarios
$consultaUsuarios = "SELECT COUNT(*) as total_usuarios FROM usuarios_app";
$resultadoUsuarios = mysqli_query($conn, $consultaUsuarios);
if (!$resultadoUsuarios) {
    die("Error en la consulta de usuarios: " . mysqli_error($conn));
}
$totalUsuarios = mysqli_fetch_assoc($resultadoUsuarios)['total_usuarios'];

// Número de animales disponibles
$consultaAnimales = "SELECT COUNT(*) as total_animales FROM animales WHERE estado = 'disponible'";
$resultadoAnimales = mysqli_query($conn, $consultaAnimales);
if (!$resultadoAnimales) {
    die("Error en la consulta de animales: " . mysqli_error($conn));
}
$totalAnimales = mysqli_fetch_assoc($resultadoAnimales)['total_animales'];

// Asignaciones pendientes
$consultaPendientes = "SELECT COUNT(*) as pendientes FROM asignaciones WHERE estado = 'pendiente'";
$resultadoPendientes = mysqli_query($conn, $consultaPendientes);
if (!$resultadoPendientes) {
    die("Error en la consulta de asignaciones pendientes: " . mysqli_error($conn));
}
$totalPendientes = mysqli_fetch_assoc($resultadoPendientes)['pendientes'];

// Asignaciones completadas
$consultaCompletadas = "SELECT COUNT(*) as completadas FROM asignaciones WHERE estado = 'completada'";
$resultadoCompletadas = mysqli_query($conn, $consultaCompletadas);
if (!$resultadoCompletadas) {
    die("Error en la consulta de asignaciones completadas: " . mysqli_error($conn));
}
$totalCompletadas = mysqli_fetch_assoc($resultadoCompletadas)['completadas'];

// Resultados recientes de tests
$consultaTests = "
    SELECT
        u.usuario_id,
        u.nombre,
        u.tipo_usuario,
        t.resultado_test,
        a.estado_asignacion,
        a.animal_asignado,
        a.fecha_asignacion
    FROM tests t
    JOIN usuarios_app u ON t.usuario_id = u.usuario_id
    JOIN asignaciones a ON u.usuario_id = a.usuario_id
    ORDER BY t.fecha_test DESC
    LIMIT 5
";
$resultadoTests = mysqli_query($conn, $consultaTests);
if (!$resultadoTests) {
    die("Error en la consulta de tests: " . mysqli_error($conn));
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="../assets/css/dashboard.css">
    <title>Panel de Administración</title>
</head>
<body>
<header class="dashboard-header">
    <div class="header-container">
        <img src="../assets/img/logoth.png" alt="Logo" class="logo">
        <h1>Animal Therapy - Panel de Administración</h1>
    </div>
    <a href="utils/logout.php" class="logout-button">Cerrar sesión</a>
</header>

<main class="dashboard-main">
    <section class="dashboard-panel-container">
        <div class="dashboard-panel">
            <h2>USUARIOS REGISTRADOS</h2>
            <p><?php echo $totalUsuarios; ?></p>
        </div>
        <div class="dashboard-panel">
            <h2>MASCOTAS DISPONIBLES</h2>
            <p><?php echo $totalAnimales; ?></p>
        </div>
        <div class="dashboard-panel">
            <h2>ASIGNACIONES PENDIENTES</h2>
            <p><?php echo $totalPendientes; ?></p>
        </div>
        <div class="dashboard-panel">
            <h2>ASIGNACIONES COMPLETADAS</h2>
            <p><?php echo $totalCompletadas; ?></p>
        </div>
    </section>

    <section class="dashboard-tests mt-4">
        <h2>REGISTROS</h2>
        <div class="table-responsive">
            <table class="table table-striped table-bordered">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Nombre de Usuario</th>
                        <th>Tipo de Usuario</th>
                        <th>Resultados</th>
                        <th>Estado de Asignación</th>
                        <th>Animal Asignado</th>
                        <th>Fecha de Asignación</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($filaTest = mysqli_fetch_assoc($resultadoTests)) : ?>
                        <tr>
                            <td><?php echo $filaTest['usuario_id']; ?></td>
                            <td><?php echo $filaTest['nombre']; ?></td>
                            <td><?php echo $filaTest['tipo_usuario']; ?></td>
                            <td><?php echo $filaTest['resultado_test']; ?></td>
                            <td><?php echo $filaTest['estado_asignacion']; ?></td>
                            <td><?php echo $filaTest['animal_asignado']; ?></td>
                            <td><?php echo $filaTest['fecha_asignacion']; ?></td>
                        </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </div>
    </section>
    
</main>
<?php include '../templates/footer.php'; ?>
<script src="../assets/js/bootstrap.bundle.min.js"></script>

</body>
</html>
