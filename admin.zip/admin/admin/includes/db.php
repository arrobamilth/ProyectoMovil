<?php
$host = 'localhost';
$dbname = 'pruebados';
$user = 'root';
$pass = '';

$conn = new mysqli($host, $user, $pass, $dbname);

// Verifica si hay un error en la conexión
if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}
?>
