<?php
// Función para sanitizar entradas
function sanitize_input($data) {
    return htmlspecialchars(trim($data));
}

// Función para validar correo electrónico
function validate_email($email) {
    return filter_var($email, FILTER_VALIDATE_EMAIL);
}

// Función para verificar el usuario
function verify_user($conn, $correo, $contrasena) {
    $sql = "SELECT * FROM usuarios WHERE correo = ? AND contrasena = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ss", $correo, $contrasena);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows > 0) {
        return $result->fetch_assoc();
    }
    return false;
}

// Función para redirigir
function redirect($url) {
    header("Location: $url");
    exit();
}

// Función para manejar errores
function display_error($error) {
    echo '<p style="color:red;">' . htmlspecialchars($error) . '</p>';
}
?>
